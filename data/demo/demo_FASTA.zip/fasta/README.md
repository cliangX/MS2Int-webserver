# FASTA (digestion → batch prediction) — Example

Use this folder for the web UI **FASTA** tab:

- `proteins.fasta`: two small protein sequences (standard amino acids only) so the example job runs fast.

Recommended parameters (fast run):
- Charge: select only `2+`
- CE: `30`
- FRAG: `HCD`
- Missed cleavages: `1`
- Length: `7–30`
