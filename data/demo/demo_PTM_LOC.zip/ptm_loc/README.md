# PTM LOC (phosphosite localization / FLR) — Example

Use this folder for the web UI **PTM LOC** tab:

- `msms.txt`: MaxQuant search result including `Phospho (STY)` (subset; `Raw file` is `raw1`)
- `raw1.mgf`: matching MGF file (**the filename must equal the `Raw file` value**)
- `Phospho (STY)Sites.txt`: optional upload file (included here)

Suggested parameters:
- Fragmentation: prefer `CID` (if unsure, start with the default `HCD` to validate the workflow)
- collision_energy: `30`
- target FLR: `0.01`

Note: this MGF file was reconstructed from `msms.txt` (`Masses`/`Intensities`) as a minimal peak list for quick example runs.
