# BATCH (CSV batch prediction) — Example

Use this folder for the web UI **BATCH** tab:

- `input.csv`: minimal CSV input (required columns: `Sequence,Charge,collision_energy,Fragmentation`; `Length` is optional)
- `output_example.h5`: reference output file (copied from the reference project for quick H5 inspection; **do not upload this to the webserver**)

Tip: keep the CSV small (a few peptides) so the background job finishes quickly.
