# RESCORE (rescoring pipeline) — Example

Use this folder for the web UI **RESCORE** tab:

- `msms.txt`: MaxQuant search result (small subset)
- `HF2_MS_14359_BH-E_1_22072021.mgf`: matching MGF file (**the filename must equal the `Raw file` value**, otherwise the backend cannot match spectra)

Suggested parameters (defaults are fine):
- Fragmentation: `HCD`
- collision_energy: `30`

Note: this MGF file was reconstructed from `msms.txt` (`Masses`/`Intensities`) as a minimal peak list for quick example runs.
